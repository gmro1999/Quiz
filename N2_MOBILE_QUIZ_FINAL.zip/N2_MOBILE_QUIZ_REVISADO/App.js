import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './telas/Home';
import CRUDPergunta from './telas/CRUDPergunta';
import CRUDTema from './telas/CRUDTema';
import InicioQuiz from './telas/InicioQuiz';
import PerguntaQuiz from './telas/PerguntaQuiz';
import ResultadoQuiz from './telas/ResultadoQuiz';
import { useEffect } from 'react';
import { initializeDatabase } from './services/dbService';

const Stack = createStackNavigator();

function App() {
  useEffect(() => {
    initializeDatabase();
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} options={{ title: 'N2_MOBILE_QUIZ' }} />
        <Stack.Screen name="CRUDPergunta" component={CRUDPergunta} options={{ title: 'CRUD Pergunta' }} />
        <Stack.Screen name="CRUDTema" component={CRUDTema} options={{ title: 'CRUD Tema' }} />
        <Stack.Screen name="InicioQuiz" component={InicioQuiz} options={{ title: 'Iniciar Quiz' }} />
        <Stack.Screen name="PerguntaQuiz" component={PerguntaQuiz} options={{ title: 'Quiz' }} />
        <Stack.Screen name="ResultadoQuiz" component={ResultadoQuiz} options={{ title: 'Resultado do Quiz' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
