import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';

const BotaoAcaoCRUD = ({ children, expanded, toggleExpand }) => {
  return (
    <View>
      <TouchableOpacity onPress={toggleExpand} style={styles.button}>
        <Text style={styles.buttonText}>{expanded ? "Cancelar Criação" : "Criar Novo Item"}</Text>
      </TouchableOpacity>

      {expanded && (
        <View style={styles.formContainer}>
          {children}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#6200ea', // cor roxa vibrante
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 5,
  },
  buttonText: {
    color: '#ffffff', // texto branco
    fontSize: 18,
    fontWeight: 'bold',
    letterSpacing: 1.2,
  },
  formContainer: {
    marginTop: 15,
    padding: 20,
    borderColor: '#dddddd',
    borderWidth: 1,
    borderRadius: 15,
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 4,
  },
});

export default BotaoAcaoCRUD;
