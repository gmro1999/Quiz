import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons'; // Ícones para editar e excluir

const OpcaoListaCRUD = ({ titulo, onEdit, onDelete }) => {
  return (
    <View style={styles.card}>
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{titulo}</Text>
      </View>
      <View style={styles.actionsContainer}>
        <TouchableOpacity onPress={onEdit} style={styles.actionButton}>
          <Feather name="edit" size={24} color="#4CAF50" /> {/* Ícone verde para editar */}
        </TouchableOpacity>
        <TouchableOpacity onPress={onDelete} style={styles.actionButton}>
          <Feather name="trash" size={24} color="#F44336" /> {/* Ícone vermelho para excluir */}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff', // Fundo branco para o card
    paddingVertical: 15,
    paddingHorizontal: 20,
    marginVertical: 10,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 5, // Sombra mais pronunciada para destaque
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  cardContent: {
    flex: 1,
    marginRight: 15,
  },
  cardTitle: {
    fontSize: 20, // Aumentei o tamanho da fonte
    fontWeight: 'bold',
    color: '#333', // Cor do texto mais escura para melhor contraste
  },
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: 80, // Aumentei o espaço entre os ícones
  },
  actionButton: {
    paddingHorizontal: 5,
    paddingVertical: 5,
    borderRadius: 20,
    backgroundColor: '#f0f0f0', // Fundo mais claro para os botões de ação
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default OpcaoListaCRUD;
