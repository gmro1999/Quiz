import React from 'react';
import { View, FlatList, StyleSheet, Keyboard, Button, Text, Alert } from 'react-native';
import OpcaoListaCRUD from '../viewOpcaoListaCRUD';
import BotaoAcaoCRUD from '../viewBotaoAcaoCRUD'; // Alterado o nome do botão
import FiltroCRUD from '../viewFiltroCRUD';

const ViewFullCRUD = ({
  data, // Lista de itens
  titulo, // Título de cada card
  onEdit, // Função de editar
  onDelete, // Função de deletar
  onAddOrEdit, // Função para adicionar ou editar
  formFields, // Campos do formulário
  filterValue, // Valor do filtro
  onFilterChange, // Função para mudar o filtro
  expanded, // Estado do formulário
  toggleExpand, // Função para expandir/retrair o formulário
  editingId, // ID do item que está sendo editado
  clearForm, // Função para limpar o formulário
}) => {
  
  // Função para confirmar exclusão
  const confirmDelete = (itemId) => {
    Alert.alert(
      "Confirmação de Exclusão",
      "Tem certeza de que deseja excluir este item?",
      [
        {
          text: "Não",
          style: "cancel",
        },
        {
          text: "Sim",
          onPress: () => onDelete(itemId),
        },
      ],
      { cancelable: true }
    );
  };

  const renderHeader = () => (
    <>
      <BotaoAcaoCRUD expanded={expanded} toggleExpand={() => {
        if (expanded) {
          clearForm(); // Limpa o formulário ao retrair
        }
        toggleExpand(!expanded);
      }}>
        {formFields}
        <Button
          title={editingId ? "Atualizar" : "Adicionar"}
          onPress={() => {
            onAddOrEdit();
            Keyboard.dismiss();
          }}
          color="#007BFF" // Cor do botão de adicionar/atualizar
        />
      </BotaoAcaoCRUD>

      <View style={styles.filterContainer}>
        <FiltroCRUD value={filterValue} onChangeText={onFilterChange} />
      </View>
    </>
  );

  return (
    <FlatList
      data={data}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => (
        <OpcaoListaCRUD
          titulo={titulo(item)}
          onEdit={() => onEdit(item)}
          onDelete={() => confirmDelete(item.id)} // Adiciona a verificação de exclusão
        />
      )}
      ListHeaderComponent={renderHeader()} // Cabeçalho com formulário e filtro
      ListEmptyComponent={<View style={styles.emptyMessage}><Text>Nenhum item encontrado</Text></View>}
      contentContainerStyle={{ paddingBottom: 20 }} // Espaçamento no final
    />
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f7f7f7', // Fundo atualizado para cinza claro
  },
  filterContainer: {
    marginTop: 15,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  emptyMessage: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f0f0f0', // Fundo cinza para a mensagem de vazio
    borderRadius: 10, // Bordas arredondadas para a mensagem de vazio
    marginHorizontal: 20,
  },
});

export default ViewFullCRUD;
