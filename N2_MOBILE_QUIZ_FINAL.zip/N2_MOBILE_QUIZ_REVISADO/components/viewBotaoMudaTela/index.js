import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient'; // Usando gradiente do Expo

const BotaoMudaTela = ({ text, screenName }) => {
  const navigation = useNavigation();

  return (
    <TouchableOpacity
      style={styles.buttonContainer}
      onPress={() => navigation.navigate(screenName)}
    >
      <LinearGradient
        colors={['#1E90FF', '#00BFFF']} // Gradiente de azul escuro para azul claro
        style={styles.button}
      >
        <Text style={styles.buttonText}>{text}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  buttonContainer: {
    width: '80%', // Para ocupar 80% da largura da tela
    marginVertical: 15,
    alignItems: 'center',
  },
  button: {
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
    alignItems: 'center',
    width: '100%',
    elevation: 8, // Aumento da sombra para Android
    shadowColor: '#000', // Sombra para iOS
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    letterSpacing: 1.5,
  },
});

export default BotaoMudaTela;
