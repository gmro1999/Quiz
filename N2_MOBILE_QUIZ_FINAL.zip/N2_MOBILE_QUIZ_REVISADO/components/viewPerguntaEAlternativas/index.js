import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const PerguntaEAlternativas = ({ 
  pergunta, 
  alternativas, 
  alternativaEscolhida, 
  alternativaCorreta, 
  onAlternativaChange // Função para alterar a alternativa escolhida
}) => {

  const getStyle = (index) => {
    // Caso o usuário ainda não tenha respondido
    if (alternativaCorreta === null || alternativaCorreta === undefined) {
      return index === alternativaEscolhida ? styles.alternativaSelecionada : styles.alternativaNeutra;
    }
  
    // Caso o usuário esteja no estágio de resultados
    if (alternativaEscolhida === index) {
      return index === alternativaCorreta ? styles.alternativaCorretaEscolhida : styles.alternativaErradaEscolhida;
    } else if (index === alternativaCorreta) {
      return styles.alternativaCorretaNaoEscolhida;
    } else {
      return styles.alternativaNeutraResultado;
    }
  };  

  return (
    <View style={styles.container}>
      {/* Pergunta */}
      <Text style={styles.pergunta}>{pergunta}</Text>

      {/* Alternativas */}
      {alternativas.map((alt, index) => (
        <TouchableOpacity
          key={alt.id}
          style={getStyle(index)}
          onPress={() => onAlternativaChange(index)} // Atualiza a alternativa escolhida
          disabled={!!alternativaCorreta} // Desativa as alternativas se já estiver no resultado
        >
          <View style={styles.radio}>
            {alternativaEscolhida === index && <View style={styles.radioSelecionado} />}
          </View>
          <Text style={styles.alternativaText}>{alt.texto_alternativa || alt.texto}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f5f5f5', // Cor de fundo suave para o container
    borderRadius: 10, // Arredondando as bordas
    marginBottom: 15,
  },
  pergunta: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333', // Cor mais escura para maior contraste
    marginBottom: 15,
  },
  alternativaNeutra: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 12,
    backgroundColor: '#e0e0e0', // Cinza neutro mais claro
    borderRadius: 8,
  },
  alternativaSelecionada: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 12,
    backgroundColor: '#007BFF', // Azul vibrante quando selecionada
    borderRadius: 8,
  },
  alternativaNeutraResultado: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 12,
    backgroundColor: '#fafafa', // Cinza muito claro para o resultado
    borderRadius: 8,
  },
  alternativaCorretaEscolhida: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 12,
    backgroundColor: '#4CAF50', // Verde para a resposta correta e escolhida
    borderRadius: 8,
  },
  alternativaErradaEscolhida: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 12,
    backgroundColor: '#F44336', // Vermelho para resposta errada escolhida
    borderRadius: 8,
  },
  alternativaCorretaNaoEscolhida: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 12,
    backgroundColor: '#8BC34A', // Verde claro para a resposta correta, não escolhida
    borderRadius: 8,
  },
  radio: {
    height: 22,
    width: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: '#007BFF', // Azul vibrante para o contorno do rádio
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  radioSelecionado: {
    height: 12,
    width: 12,
    borderRadius: 6,
    backgroundColor: '#007BFF', // Azul preenchido quando selecionado
  },
  alternativaText: {
    fontSize: 16,
    color: '#333', // Cor de texto mais escura
    flexWrap: 'wrap',
  },
});

export default PerguntaEAlternativas;
