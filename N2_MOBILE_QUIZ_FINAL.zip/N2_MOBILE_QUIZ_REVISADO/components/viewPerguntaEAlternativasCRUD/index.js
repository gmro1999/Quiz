import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const PerguntaEAlternativasCRUD = ({ alternativas, alternativaEscolhida, onAlternativaChange, onSelectAlternativaCorreta }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.legend}>Selecione a resposta correta e preencha as opções:</Text>
      {alternativas.map((alt, index) => (
        <View key={index} style={styles.alternativaContainer}>
          {/* Radio Button à esquerda */}
          <TouchableOpacity onPress={() => onSelectAlternativaCorreta(index)} style={styles.radio}>
            {alternativaEscolhida === index && <View style={styles.radioSelecionado} />}
          </TouchableOpacity>
          
          {/* Campo de texto da alternativa */}
          <TextInput
            style={styles.alternativaInput}
            placeholder={`Opção ${index + 1}`}
            value={alt.texto}
            onChangeText={(texto) => onAlternativaChange(index, texto)}
          />
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
    paddingHorizontal: 10,
    paddingVertical: 15,
    backgroundColor: '#f9f9f9', // Cor de fundo suave
    borderRadius: 10, // Borda arredondada
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3, // Sombra para Android
  },
  legend: {
    fontSize: 18, // Aumentei o tamanho da fonte
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333', // Cor de texto mais escura
  },
  alternativaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    paddingVertical: 8,
    backgroundColor: '#fff', // Fundo branco para as alternativas
    borderRadius: 8, // Borda mais arredondada para as alternativas
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2, // Sombra leve para as alternativas
  },
  radio: {
    height: 22,
    width: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: '#007BFF', // Azul vibrante para os botões de rádio
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 15,
  },
  radioSelecionado: {
    height: 12,
    width: 12,
    borderRadius: 6,
    backgroundColor: '#007BFF', // Azul preenchido quando selecionado
  },
  alternativaInput: {
    flex: 1,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8, // Borda arredondada para o campo de entrada
    backgroundColor: '#f1f1f1', // Fundo leve para o campo de entrada
    fontSize: 16,
  },
});

export default PerguntaEAlternativasCRUD;
