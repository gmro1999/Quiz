import { database } from './dbService';

// CREATE
export async function createTema(nome) {
  const sql = 'INSERT INTO TEMA (nome) VALUES (?);';
  const params = [nome];
  const result = await database.query(sql, params);
  return result.changes === 1;
}

// READ (todos os temas)
export async function getAllTemas() {
  const sql = 'SELECT * FROM TEMA;';
  const result = await database.getAll(sql); // Correção para utilizar getAll
  return result;
}

// READ (tema pelo ID)
export async function getTemaById(id) {
  const sql = 'SELECT * FROM TEMA WHERE id = ?;';
  const params = [id];
  const result = await database.query(sql, params);
  return result.rows.length ? result.rows.item(0) : null;
}

// UPDATE
export async function updateTema(id, nome) {
  const sql = 'UPDATE TEMA SET nome = ? WHERE id = ?;';
  const params = [nome, id];
  const result = await database.query(sql, params);
  return result.changes === 1;
}

// DELETE
export async function deleteTema(id) {
  const sql = 'DELETE FROM TEMA WHERE id = ?;';
  const params = [id];
  const result = await database.query(sql, params);
  return result.changes === 1;
}
