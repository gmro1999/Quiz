import { database } from './dbService';

// CREATE
export async function createAlternativa(texto_alternativa, pergunta_id, e_certa) {
  const sql = 'INSERT INTO ALTERNATIVAS (texto_alternativa, pergunta_id, e_certa) VALUES (?, ?, ?);';
  const params = [texto_alternativa, pergunta_id, e_certa];
  const result = await database.query(sql, params);
  return result.changes === 1; // Verifica se a alteração foi feita corretamente
}

// READ (todas as alternativas)
export async function getAllAlternativas() {
  const sql = 'SELECT * FROM ALTERNATIVAS;';
  const result = await database.getAll(sql); // Corrigido para usar getAll
  return result || []; // Garante que sempre retorna um array
}

// READ (alternativas pelo ID da pergunta)
export async function getAlternativasByPerguntaId(pergunta_id) {
  const sql = 'SELECT * FROM ALTERNATIVAS WHERE pergunta_id = ?;';
  const params = [pergunta_id];
  const result = await database.getAll(sql, params); // Corrigido para usar getAll
  return result || []; // Garante que sempre retorna um array
}

// UPDATE
export async function updateAlternativa(id, texto_alternativa, e_certa) {
  const sql = 'UPDATE ALTERNATIVAS SET texto_alternativa = ?, e_certa = ? WHERE id = ?;';
  const params = [texto_alternativa, e_certa, id];
  const result = await database.query(sql, params);
  return result.changes === 1; // Verifica se a alteração foi feita corretamente
}

// DELETE
export async function deleteAlternativa(id) {
  const sql = 'DELETE FROM ALTERNATIVAS WHERE id = ?;';
  const params = [id];
  const result = await database.query(sql, params);
  return result.changes === 1; // Verifica se a alteração foi feita corretamente
}

// DELETE (alternativas pelo ID da pergunta)
export async function deleteAlternativaByPerguntaId(pergunta_id) {
  const sql = 'DELETE FROM ALTERNATIVAS WHERE pergunta_id = ?;';
  const params = [pergunta_id];
  const result = await database.query(sql, params);
  return result.changes > 0; // Verifica se pelo menos uma linha foi alterada
}
