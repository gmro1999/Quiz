import { database } from './dbService';
import { getAlternativasByPerguntaId } from './AlternativaService'; // Importa o serviço de alternativas

// CREATE
export async function createPergunta(texto_pergunta, tema_id) {
  const sql = 'INSERT INTO PERGUNTAS (texto_pergunta, tema_id) VALUES (?, ?);';
  const params = [texto_pergunta, tema_id];
  const result = await database.query(sql, params);
  
  // Retorna o ID da pergunta recém-criada
  return result ? result.lastInsertRowId : 0;
}

// READ (todas as perguntas)
export async function getAllPerguntas() {
  const sql = 'SELECT * FROM PERGUNTAS;';
  const result = await database.getAll(sql);
  return result || [];  // Certifique-se de retornar um array vazio se não houver resultados
}

// READ (perguntas pelo ID do tema)
export async function getPerguntasByTemaId(tema_id) {
  const sql = 'SELECT * FROM PERGUNTAS WHERE tema_id = ?;';
  const params = [tema_id];
  const result = await database.getAll(sql, params);
  return result || [];  // Certifique-se de retornar um array vazio se não houver resultados
}


// READ (perguntas pelo ID do tema, com alternativas)
export async function getPerguntasComAlternativasByTemaId(tema_id) {
  const sql = 'SELECT * FROM PERGUNTAS WHERE tema_id = ?;';
  const params = [tema_id];
  const perguntas = await database.getAll(sql, params); // Obtém as perguntas para o tema

  // Verifica se há perguntas
  if (!perguntas || perguntas.length === 0) {
    console.log("Nenhuma pergunta encontrada para o tema", tema_id);
    return [];
  }

  // Para cada pergunta, buscar as alternativas e associá-las
  for (let i = 0; i < perguntas.length; i++) {
    
    const alternativas = await getAlternativasByPerguntaId(perguntas[i].id);
    // Adiciona as alternativas ou retorna array vazio
    perguntas[i].alternativas = alternativas || [];
    
    console.log("Alternativas para a pergunta", perguntas[i].id, alternativas);
  }

  return perguntas;
}


// UPDATE
export async function updatePergunta(id, texto_pergunta) {
  const sql = 'UPDATE PERGUNTAS SET texto_pergunta = ? WHERE id = ?;';
  const params = [texto_pergunta, id];
  const result = await database.query(sql, params);
  return result ? result.changes : 0;
}

// DELETE
export async function deletePergunta(id) {
  const sql = 'DELETE FROM PERGUNTAS WHERE id = ?;';
  const params = [id];
  const result = await database.query(sql, params);
  return result ? result.changes : 0;
}
