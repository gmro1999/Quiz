import * as SQLite from 'expo-sqlite/next';

class Sqlite3Connector {
  constructor() {
    this.databaseConnector = null;
  }

  async configureConnection() {
    if (!this.databaseConnector) {
      this.databaseConnector = await SQLite.openDatabaseAsync('quiz.db', { useNewConnection: true });
      if (this.databaseConnector) {
        console.log('Database Connected');
      } else {
        console.log('Database Not Connected');
        throw new Error('Database connection failed.');
      }
    }
    return this.databaseConnector;
  }

  async query(sql, params = []) {
    const db = await this.configureConnection();
    try {
      const result = await db.runAsync(sql, params);
      return result;
    } catch (error) {
      console.error('Erro na consulta SQL:', error);
      throw error;
    }
  }

  async getAll(sql, params = []) {
    const db = await this.configureConnection();
    try {
      const result = await db.getAllAsync(sql, params);
      return result;
    } catch (error) {
      console.error('Erro ao buscar dados:', error);
      throw error;
    }
  }

  async withTransaction(sqlStatements) {
    const db = await this.configureConnection();
    try {
      await db.withTransactionAsync(async () => {
        for (const { sql, params } of sqlStatements) {
          await db.runAsync(sql, params);
        }
      });
    } catch (error) {
      console.error('Erro na transação:', error);
      throw error;
    }
  }

  async createTables() {
    const db = await this.configureConnection();

    const createTemaTable = `
      CREATE TABLE IF NOT EXISTS TEMA (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL
      );
    `;

    const createPerguntasTable = `
      CREATE TABLE IF NOT EXISTS PERGUNTAS (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        texto_pergunta TEXT NOT NULL,
        tema_id INTEGER,
        FOREIGN KEY (tema_id) REFERENCES TEMA(id)
      );
    `;

    const createAlternativasTable = `
      CREATE TABLE IF NOT EXISTS ALTERNATIVAS (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        texto_alternativa TEXT NOT NULL,
        pergunta_id INTEGER,
        e_certa INTEGER,
        FOREIGN KEY (pergunta_id) REFERENCES PERGUNTAS(id)
      );
    `;

    try {
      await db.withTransactionAsync(async () => {
        await db.execAsync(createTemaTable);
        await db.execAsync(createPerguntasTable);
        await db.execAsync(createAlternativasTable);
      });
      console.log('Tabelas criadas com sucesso.');
    } catch (error) {
      console.error('Erro ao criar tabelas:', error);
    }
  }
}

// Instância global do banco de dados
export const database = new Sqlite3Connector();

// Função para inicializar o banco de dados e criar as tabelas
export async function initializeDatabase() {
  try {
    await database.createTables();
    console.log('Banco de dados inicializado.');
  } catch (error) {
    console.error('Erro ao inicializar banco de dados:', error);
  }
}
