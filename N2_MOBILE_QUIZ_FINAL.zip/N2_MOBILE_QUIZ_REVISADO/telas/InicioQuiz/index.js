import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { getAllTemas } from '../../services/TemaService';
import { getPerguntasByTemaId } from '../../services/PerguntaService';

const InicioQuiz = ({ navigation }) => {
  const [temas, setTemas] = useState([]);
  const [temaSelecionado, setTemaSelecionado] = useState(null);
  const [quantidadePerguntas, setQuantidadePerguntas] = useState('');
  const [quantidadeMaximaPerguntas, setQuantidadeMaximaPerguntas] = useState(0);

  useEffect(() => {
    loadTemas();
  }, []);

  const loadTemas = async () => {
    try {
      const temasDb = await getAllTemas();
      setTemas(temasDb);
    } catch (error) {
      console.error('Erro ao carregar temas:', error);
    }
  };

  const handleTemaChange = async (temaId) => {
    setTemaSelecionado(temaId);
    try {
      const perguntas = await getPerguntasByTemaId(temaId);
      setQuantidadeMaximaPerguntas(perguntas.length);
    } catch (error) {
      console.error('Erro ao carregar perguntas:', error);
    }
  };

  const iniciarQuiz = () => {
    if (!temaSelecionado || quantidadePerguntas <= 0 || quantidadePerguntas > quantidadeMaximaPerguntas) {
      Alert.alert('Erro', 'Selecione um tema e uma quantidade de perguntas válida.');
      return;
    }
    navigation.navigate('PerguntaQuiz', { temaId: temaSelecionado, quantidadePerguntas: parseInt(quantidadePerguntas) });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Escolha um tema:</Text>
      <Picker
        selectedValue={temaSelecionado}
        onValueChange={(itemValue) => handleTemaChange(itemValue)}
        style={styles.picker}
      >
        <Picker.Item label="Selecione um tema" value={null} />
        {temas.map(tema => (
          <Picker.Item key={tema.id} label={tema.nome} value={tema.id} />
        ))}
      </Picker>

      <Text style={styles.label}>Número de perguntas (Máximo: {quantidadeMaximaPerguntas})</Text>
      <TextInput
        style={styles.input}
        value={quantidadePerguntas}
        onChangeText={setQuantidadePerguntas}
        keyboardType="numeric"
        placeholder="Digite a quantidade de perguntas"
      />

      <Button title="Iniciar Quiz" onPress={iniciarQuiz} color="#007BFF" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#F0F8FF',
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
    color: '#333',
  },
  picker: {
    backgroundColor: '#fff',
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 20,
    borderRadius: 8,
  },
  input: {
    backgroundColor: '#fff',
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    borderRadius: 8,
    marginBottom: 20,
  },
});

export default InicioQuiz;
