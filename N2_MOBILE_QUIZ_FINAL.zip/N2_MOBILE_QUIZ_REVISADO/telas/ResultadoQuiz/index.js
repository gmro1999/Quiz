import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, Button } from 'react-native';
import PerguntaEAlternativas from '../../components/viewPerguntaEAlternativas';

const ResultadoQuiz = ({ route, navigation }) => {
  const { resultado } = route.params || { resultado: [] };
  const [qtdAcertos, setQtdAcertos] = useState(0);
  const totalQuestoes = resultado.length;

  useEffect(() => {
    if (totalQuestoes > 0) {
      const acertos = resultado.reduce((acc, item) => acc + (item.correta === item.escolhida ? 1 : 0), 0);
      setQtdAcertos(acertos);
    }
  }, [resultado]);

  const taxaAcertos = totalQuestoes > 0 ? ((100 * qtdAcertos) / totalQuestoes).toFixed(2) : 0;

  const restartQuiz = () => {
    navigation.navigate('InicioQuiz');
  };

  return (
    <View style={styles.container}>
      <View style={styles.resultHeader}>
        <Text style={styles.resultText}>Você acertou {qtdAcertos} de {totalQuestoes} perguntas!</Text>
        <Text style={styles.taxaText}>Taxa de acertos: {taxaAcertos}%</Text>
      </View>

      <FlatList
        data={resultado}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.perguntaContainer}>
            <Text style={styles.perguntaText}>{item.pergunta}</Text>
            <PerguntaEAlternativas
              pergunta={item.pergunta}
              alternativas={item.alternativas}
              alternativaEscolhida={item.escolhida}
              alternativaCorreta={item.correta}
            />
          </View>
        )}
        contentContainerStyle={styles.flatListContainer}
        ListEmptyComponent={<Text style={styles.noQuestionsText}>Nenhuma pergunta respondida.</Text>}
      />

      <Button title="Recomeçar Quiz" onPress={restartQuiz} color="#28A745" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#F0F8FF',
  },
  resultHeader: {
    marginBottom: 20,
    alignItems: 'center',
  },
  resultText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#007BFF',
  },
  taxaText: {
    fontSize: 18,
    color: '#28A745',
    marginTop: 10,
  },
  flatListContainer: {
    flexGrow: 1,
  },
  perguntaContainer: {
    marginBottom: 20,
    padding: 15,
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    borderColor: '#DDD',
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
  },
  perguntaText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  noQuestionsText: {
    fontSize: 16,
    color: '#888',
    textAlign: 'center',
    marginTop: 20,
  },
});

export default ResultadoQuiz;
