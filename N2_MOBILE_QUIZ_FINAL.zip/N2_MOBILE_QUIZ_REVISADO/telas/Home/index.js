import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const Home = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Quiz App</Text>

      <View style={styles.buttonContainer}>
        {/* Botão para iniciar o quiz */}
        <Button
          title="Jogar Quiz"
          onPress={() => navigation.navigate('InicioQuiz')}
          color="#007BFF"
        />
        {/* Botão para gerenciar temas */}
        <Button
          title="Gerenciar Temas"
          onPress={() => navigation.navigate('CRUDTema')}
          color="#28A745"
        />
        {/* Botão para gerenciar perguntas */}
        <Button
          title="Gerenciar Perguntas"
          onPress={() => navigation.navigate('CRUDPergunta')}
          color="#FFC107"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#E8F5FF',
    padding: 20,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#333',
  },
  buttonContainer: {
    width: '80%',
    justifyContent: 'space-between',
    height: 200, // Aumentado para espaçar melhor os botões
  },
});

export default Home;
