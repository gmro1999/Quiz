import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, FlatList, Alert, Text, StyleSheet } from 'react-native';
import { getAllTemas } from '../../services/TemaService';
import { createPergunta, getAllPerguntas, updatePergunta, deletePergunta, getPerguntasComAlternativasByTemaId } from '../../services/PerguntaService';
import { createAlternativa, deleteAlternativaByPerguntaId, getAlternativasByPerguntaId } from '../../services/AlternativaService';

const CRUDPergunta = () => {
  const [textoPergunta, setTextoPergunta] = useState('');
  const [temaId, setTemaId] = useState(null);
  const [temas, setTemas] = useState([]);
  const [perguntas, setPerguntas] = useState([]);
  const [alternativas, setAlternativas] = useState([
    { id: null, texto: '', e_certa: false },
    { id: null, texto: '', e_certa: false },
    { id: null, texto: '', e_certa: false },
    { id: null, texto: '', e_certa: false },
  ]);
  const [alternativaEscolhida, setAlternativaEscolhida] = useState(null);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    loadTemas();
    loadPerguntas();
  }, []);

  const loadTemas = async () => {
    try {
      const temasDb = await getAllTemas();
      setTemas(temasDb || []);
    } catch (error) {
      console.error('Erro ao carregar temas:', error);
    }
  };

  const loadPerguntas = async () => {
    try {
      const perguntasDb = await getAllPerguntas();
      setPerguntas(perguntasDb || []);
    } catch (error) {
      console.error('Erro ao carregar perguntas:', error);
    }
  };

  const handleAddOrEditPergunta = async () => {
    if (!temaId || !textoPergunta || alternativas.some(a => a.texto === '') || alternativaEscolhida === null) {
      Alert.alert('Erro', 'Preencha todos os campos e selecione a alternativa correta.');
      return;
    }

    try {
      let perguntaId;

      if (editingId) {
        await updatePergunta(editingId, textoPergunta); // Atualiza a pergunta
        perguntaId = editingId;
        Alert.alert('Pergunta atualizada!');
        await deleteAlternativaByPerguntaId(perguntaId); // Exclui alternativas antigas antes de adicionar novas
      } else {
        perguntaId = await createPergunta(textoPergunta, temaId); // Cria nova pergunta
        Alert.alert('Pergunta adicionada!');
      }

      // Cria as novas alternativas
      for (let i = 0; i < alternativas.length; i++) {
        const alternativa = alternativas[i];
        if (alternativa.texto) {
          await createAlternativa(alternativa.texto, perguntaId, i === alternativaEscolhida ? 1 : 0);
        }
      }

      clearForm(); // Limpa o formulário após adicionar/atualizar
      loadPerguntas();
    } catch (error) {
      console.error('Erro ao salvar a pergunta e alternativas:', error);
      Alert.alert('Erro ao salvar a pergunta e alternativas!');
    }
  };

  const handleEdit = async (item) => {
    setTextoPergunta(item.texto_pergunta);
    setTemaId(item.tema_id); // Mantém o ID do tema selecionado
    setEditingId(item.id);

    try {
      const alternativasDb = await getAlternativasByPerguntaId(item.id);

      if (alternativasDb.length > 0) {
        setAlternativas(alternativasDb.map(alt => ({
          id: alt.id,
          texto: alt.texto_alternativa,
          e_certa: alt.e_certa === 1,
        })));

        const corretaIndex = alternativasDb.findIndex(alt => alt.e_certa === 1);
        setAlternativaEscolhida(corretaIndex);
      } else {
        setAlternativas([
          { id: null, texto: '', e_certa: false },
          { id: null, texto: '', e_certa: false },
          { id: null, texto: '', e_certa: false },
          { id: null, texto: '', e_certa: false },
        ]);
        setAlternativaEscolhida(null);
      }
    } catch (error) {
      console.error('Erro ao carregar alternativas:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await deletePergunta(id);
      Alert.alert('Pergunta excluída!');
      loadPerguntas();
      clearForm();
    } catch (error) {
      console.error('Erro ao excluir a pergunta:', error);
      Alert.alert('Erro ao excluir a pergunta!');
    }
  };

  const clearForm = () => {
    setTextoPergunta('');
    setTemaId(null);
    setAlternativas([
      { id: null, texto: '', e_certa: false },
      { id: null, texto: '', e_certa: false },
      { id: null, texto: '', e_certa: false },
      { id: null, texto: '', e_certa: false },
    ]);
    setAlternativaEscolhida(null);
    setEditingId(null);
  };

  const handleAlternativaChange = (index, texto) => {
    const novasAlternativas = [...alternativas];
    novasAlternativas[index].texto = texto;
    setAlternativas(novasAlternativas);
  };

  const getAlternativasDescricao = (alternativas) => {
    return alternativas && alternativas.length > 0
      ? alternativas.map((alt) => (alt.e_certa ? alt.texto.toUpperCase() : alt.texto)).join(', ')
      : 'Sem alternativas cadastradas';
  };

  return (
    <View style={styles.container}>
      {/* Formulário de Perguntas */}
      <TextInput
        style={styles.input}
        placeholder="Texto da pergunta"
        value={textoPergunta}
        onChangeText={setTextoPergunta}
      />

      {/* Lista de temas */}
      <FlatList
        data={temas}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <Button title={item.nome} onPress={() => setTemaId(item.id)} color={item.id === temaId ? '#007BFF' : '#8e8e8e'} />
        )}
        horizontal={true}
        contentContainerStyle={styles.temaList}
      />

      {/* Campos para alternativas */}
      {alternativas.map((alt, index) => (
        <View key={index} style={styles.alternativaContainer}>
          <TextInput
            style={styles.inputAlternativa}
            placeholder={`Alternativa ${index + 1}`}
            value={alt.texto}
            onChangeText={(text) => handleAlternativaChange(index, text)}
          />
          <Button
            title={alternativaEscolhida === index ? 'Correta' : 'Correta?'}
            onPress={() => setAlternativaEscolhida(index)}
            color={alternativaEscolhida === index ? 'green' : 'gray'}
          />
        </View>
      ))}

      <Button title={editingId ? "Atualizar Pergunta" : "Adicionar Pergunta"} onPress={handleAddOrEditPergunta} color="#28a745" />

      {/* Lista de perguntas */}
      <FlatList
        data={perguntas}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Text style={styles.perguntaText}>{item.texto_pergunta}</Text>
            <View style={styles.actions}>
              <Button title="Editar" onPress={() => handleEdit(item)} />
              <Button title="Excluir" onPress={() => handleDelete(item.id)} color="red" />
            </View>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f4f4f4',
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    borderRadius: 5,
    marginBottom: 15,
    backgroundColor: '#fff',
    fontSize: 16,
  },
  inputAlternativa: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    borderRadius: 5,
    flex: 1,
    marginRight: 10,
    backgroundColor: '#fff',
    fontSize: 16,
  },
  alternativaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  temaList: {
    marginBottom: 20,
  },
  itemContainer: {
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  perguntaText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  alternativasText: {
    fontSize: 16,
    color: '#555',
    marginBottom: 10,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default CRUDPergunta;
