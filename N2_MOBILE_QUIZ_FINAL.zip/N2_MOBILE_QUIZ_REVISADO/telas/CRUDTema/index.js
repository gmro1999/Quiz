import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, FlatList, Alert, Text, StyleSheet } from 'react-native';
import { createTema, getAllTemas, updateTema, deleteTema } from '../../services/TemaService';

const CRUDTema = () => {
  const [nomeTema, setNomeTema] = useState('');
  const [temas, setTemas] = useState([]);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    loadTemas();
  }, []);

  const loadTemas = async () => {
    try {
      const temasDb = await getAllTemas();
      setTemas(temasDb || []);
    } catch (error) {
      console.error('Erro ao carregar temas:', error);
    }
  };

  const handleAddOrEditTema = async () => {
    if (!nomeTema.trim()) {
      Alert.alert('Atenção', 'O nome do tema não pode estar vazio.');
      return;
    }
    try {
      if (editingId) {
        await updateTema(editingId, nomeTema);
        Alert.alert('Sucesso', 'Tema atualizado!');
      } else {
        await createTema(nomeTema);
        Alert.alert('Sucesso', 'Tema adicionado!');
      }
      clearForm();
      loadTemas();
    } catch (error) {
      Alert.alert('Erro', 'Falha ao salvar o tema.');
    }
  };

  const handleEdit = (item) => {
    setNomeTema(item.nome);
    setEditingId(item.id);
  };

  const handleDelete = async (id) => {
    try {
      await deleteTema(id);
      Alert.alert('Sucesso', 'Tema excluído.');
      loadTemas();
    } catch (error) {
      Alert.alert('Erro', 'Falha ao excluir o tema.');
    }
  };

  const clearForm = () => {
    setNomeTema('');
    setEditingId(null);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerenciar Temas</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Nome do tema"
        value={nomeTema}
        onChangeText={setNomeTema}
      />
      <Button title={editingId ? "Atualizar Tema" : "Adicionar Tema"} onPress={handleAddOrEditTema} />

      <FlatList
        data={temas}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Text style={styles.itemText}>{item.nome}</Text>
            <View style={styles.actions}>
              <Button title="Editar" onPress={() => handleEdit(item)} />
              <Button title="Excluir" onPress={() => handleDelete(item.id)} color="red" />
            </View>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f8f8f8',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
    backgroundColor: '#fff',
  },
  itemContainer: {
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 5,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 2,
  },
  itemText: {
    fontSize: 18,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default CRUDTema;
