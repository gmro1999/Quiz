import React, { useState, useEffect } from 'react';
import { View, Text, Button, Alert, StyleSheet } from 'react-native';
import PerguntaEAlternativas from '../../components/viewPerguntaEAlternativas';
import { getPerguntasComAlternativasByTemaId } from '../../services/PerguntaService';

const PerguntaQuiz = ({ route, navigation }) => {
  const { temaId, quantidadePerguntas } = route.params;
  const [perguntas, setPerguntas] = useState([]);
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [alternativaEscolhida, setAlternativaEscolhida] = useState(null);
  const [resultado, setResultado] = useState([]);

  useEffect(() => {
    loadPerguntas();
  }, []);

  // Função para embaralhar as perguntas (opcional)
  const shuffleArray = (array) => {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  };

  const loadPerguntas = async () => {
    try {
      const perguntasDb = await getPerguntasComAlternativasByTemaId(temaId);
      if (perguntasDb && perguntasDb.length > 0) {
        const shuffledPerguntas = shuffleArray(perguntasDb).slice(0, quantidadePerguntas);
        setPerguntas(shuffledPerguntas);
      } else {
        Alert.alert('Erro', 'Nenhuma pergunta encontrada.');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro ao carregar perguntas.');
    }
  };

  // Efeito para navegar para ResultadoQuiz quando todas as perguntas forem respondidas
  useEffect(() => {
    if (resultado.length === perguntas.length && perguntas.length > 0) {
      navigation.navigate('ResultadoQuiz', { resultado });
    }
  }, [resultado]); // Monitora o array `resultado`

  const confirmarResposta = () => {
    if (alternativaEscolhida === null) {
      Alert.alert('Erro', 'Selecione uma alternativa.');
      return;
    }

    const perguntaAtualObj = perguntas[perguntaAtual];
    const correta = perguntaAtualObj.alternativas.findIndex(alt => alt.e_certa === 1);

    // Atualiza o resultado com a resposta
    setResultado((prevResultado) => [
      ...prevResultado,
      {
        pergunta: perguntaAtualObj.texto_pergunta,
        alternativas: perguntaAtualObj.alternativas,
        correta: correta,
        escolhida: alternativaEscolhida,
      },
    ]);

    // Verifica se há mais perguntas para responder
    if (perguntaAtual + 1 < perguntas.length) {
      setPerguntaAtual(perguntaAtual + 1);
      setAlternativaEscolhida(null);
    }
  };

  if (perguntas.length === 0) {
    return (
      <View style={styles.container}>
        <Text>Carregando perguntas...</Text>
      </View>
    );
  }

  const alternativas = perguntas[perguntaAtual]?.alternativas;

  return (
    <View style={styles.container}>
      <Text style={styles.questionText}>Pergunta {perguntaAtual + 1} de {perguntas.length}</Text>

      {alternativas && alternativas.length > 0 ? (
        <PerguntaEAlternativas
          pergunta={perguntas[perguntaAtual].texto_pergunta}
          alternativas={alternativas}
          alternativaEscolhida={alternativaEscolhida}
          onAlternativaChange={setAlternativaEscolhida}
        />
      ) : (
        <Text>Carregando alternativas...</Text>
      )}

      <Button title="Confirmar Resposta" onPress={confirmarResposta} color="#007BFF" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#F0F8FF',
  },
  questionText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

export default PerguntaQuiz;
